//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import main.Game;
import main.SpriteAnimationTester;
public class Main {
    public static void main(String[] args) {

        Game game = new Game();
        //FOR TESTING SPRITES ANIMATIONS
        //SpriteAnimationTester.launch();
    }
}